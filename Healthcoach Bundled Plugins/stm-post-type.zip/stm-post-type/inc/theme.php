<?php
add_action('vc_after_init', function (){
	if( function_exists( 'vc_add_shortcode_param' ) ) {

		vc_add_shortcode_param( 'vc_stm_datepicker', 'vc_stm_datepicker_settings_field' );

		function vc_stm_datepicker_settings_field( $settings, $value ) {
			$uni = uniqid( 'datetimepicker-' . rand() );

			return '<div class="vc_stm_datepicker">'
				.'<input id="'. $uni .'" name="' . esc_attr( $settings['param_name'] ) . '" class="wpb_vc_param_value ' .
				esc_attr( $settings['param_name'] ) . ' ' .
				esc_attr( $settings['type'] ) . '_field" type="text" value="' . esc_attr( $value ) . '" />'
				.'</div>' .
				'<script type="text/javascript">
                    jQuery(document).ready(function(){
                        var datepickerId = "#' . esc_js( $uni ) . '";

                        jQuery( datepickerId ).datetimepicker({
                            timepicker  : false,
                            format : "m/d/Y"
                        });
                    })
                </script>';
		}
	}
});
