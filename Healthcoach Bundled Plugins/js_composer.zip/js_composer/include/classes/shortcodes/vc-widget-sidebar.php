<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Widget_sidebar
 */
class WPBakeryShortCode_Vc_Widget_Sidebar extends WPBakeryShortCode {
}
