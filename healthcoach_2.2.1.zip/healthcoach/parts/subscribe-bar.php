<section class="subscribe subscribe-bar subscribe-inline subscribe_type_default">
	<div class="container">
		<div class="subscribe-bar__inner">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					<div class="subscribe-bar__desc">
						<div class="subscribe-bar__desc-icon"><span class="lnr lnr-gift"></span></div>
						<div class="subscribe-bar__desc-text"><?php _e( 'Subscribe for special offers', 'healthcoach' ) ?></div>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					<?php mc4wp_show_form(); ?>
				</div>
			</div>
		</div>
	</div>
</section>
