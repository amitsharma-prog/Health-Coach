<?php $stm_icons = array (
  0 => 
  array (
    'hc-icon-cycling' => 'cycling',
  ),
  1 => 
  array (
    'hc-icon-runner-left' => 'runner-left',
  ),
  2 => 
  array (
    'hc-icon-stretches' => 'stretches',
  ),
  3 => 
  array (
    'hc-icon-treadmil' => 'treadmil',
  ),
  4 => 
  array (
    'hc-icon-weight-rounded' => 'weight-rounded',
  ),
  5 => 
  array (
    'hc-icon-yoga' => 'yoga',
  ),
  6 => 
  array (
    'hc-icon-arrow-top' => 'arrow-top',
  ),
  7 => 
  array (
    'hc-icon-paper' => 'paper',
  ),
  8 => 
  array (
    'hc-icon-quote' => 'quote',
  ),
  9 => 
  array (
    'hc-icon-headphones' => 'headphones',
  ),
  10 => 
  array (
    'hc-icon-circle' => 'circle',
  ),
  11 => 
  array (
    'hc-icon-drugs' => 'drugs',
  ),
  12 => 
  array (
    'hc-icon-apple-o' => 'apple-o',
  ),
  13 => 
  array (
    'hc-icon-stopwatch' => 'stopwatch',
  ),
  14 => 
  array (
    'hc-icon-dumbbell-circle' => 'dumbbell-circle',
  ),
  15 => 
  array (
    'hc-icon-smile' => 'smile',
  ),
  16 => 
  array (
    'hc-icon-leaf' => 'leaf',
  ),
  17 => 
  array (
    'hc-icon-bottle' => 'bottle',
  ),
  18 => 
  array (
    'hc-icon-apple' => 'apple',
  ),
  19 => 
  array (
    'hc-icon-big-arrow-r' => 'big-arrow-r',
  ),
  20 => 
  array (
    'hc-icon-arrow-r' => 'arrow-r',
  ),
  21 => 
  array (
    'hc-icon-big-arrow-l' => 'big-arrow-l',
  ),
  22 => 
  array (
    'hc-icon-pill' => 'pill',
  ),
  23 => 
  array (
    'hc-icon-pulse' => 'pulse',
  ),
  24 => 
  array (
    'hc-icon-balance' => 'balance',
  ),
  25 => 
  array (
    'hc-icon-video' => 'video',
  ),
  26 => 
  array (
    'hc-icon-bottle-1' => 'bottle-1',
  ),
  27 => 
  array (
    'hc-icon-dumbbell' => 'dumbbell',
  ),
  28 => 
  array (
    'hc-icon-wheat' => 'wheat',
  ),
  29 => 
  array (
    'hc-icon-heart' => 'heart',
  ),
  30 => 
  array (
    'hc-icon-heart-o' => 'heart-o',
  ),
  31 => 
  array (
    'hc-icon-watermelon-o' => 'watermelon-o',
  ),
  32 => 
  array (
    'hc-icon-key' => 'key',
  ),
  33 => 
  array (
    'hc-icon-grid' => 'grid',
  ),
  34 => 
  array (
    'hc-icon-post' => 'post',
  ),
  35 => 
  array (
    'hc-icon-flash' => 'flash',
  ),
  36 => 
  array (
    'hc-icon-run' => 'run',
  ),
  37 => 
  array (
    'hc-icon-run-2' => 'run-2',
  ),
  38 => 
  array (
    'hc-icon-shield' => 'shield',
  ),
  39 => 
  array (
    'hc-icon-shoes' => 'shoes',
  ),
  40 => 
  array (
    'hc-icon-blank' => 'blank',
  ),
  41 => 
  array (
    'hc-icon-lifebuoy' => 'lifebuoy',
  ),
  42 => 
  array (
    'hc-icon-tea' => 'tea',
  ),
  43 => 
  array (
    'hc-icon-tea-2' => 'tea-2',
  ),
  44 => 
  array (
    'hc-icon-hourglass' => 'hourglass',
  ),
  45 => 
  array (
    'hc-icon-checked' => 'checked',
  ),
  46 => 
  array (
    'hc-icon-checked-2' => 'checked-2',
  ),
  47 => 
  array (
    'hc-icon-vitamins' => 'vitamins',
  ),
  48 => 
  array (
    'hc-icon-female' => 'female',
  ),
  49 => 
  array (
    'hc-icon-male' => 'male',
  ),
  50 => 
  array (
    'hc-icon-waist' => 'waist',
  ),
);