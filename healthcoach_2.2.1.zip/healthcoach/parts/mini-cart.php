<i class="fa fa-shopping-cart"></i>
<span class="user-menu__text user-menu__text_cart_count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
<div class="mini-cart mini-cart_type_user-menu">
	<ul class="mini-cart__products">

	<?php if ( ! WC()->cart->is_empty() ) : ?>

		<?php
			foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
				$_product     = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
				$product_id   = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

				if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
					$product_name      = apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key );
					$thumbnail         = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key );
					$product_price     = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
					$product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
					?>
					<li class="mini-cart__product clearfix">
						<div class="mini-cart__product-left">
						<?php if ( ! $_product->is_visible() ) : ?>
							<?php echo str_replace( array( 'http:', 'https:' ), '', $thumbnail ); ?>
						<?php else : ?>
							<a class="mini-cart__product-link" href="<?php echo esc_url( $product_permalink ); ?>">
								<?php echo str_replace( array( 'http:', 'https:' ), '', $thumbnail ); ?>
							</a>
						<?php endif; ?>
						</div>
						<div class="mini-cart__product-body">
							<?php if ( ! $_product->is_visible() ) : ?>
								<span class="mini-cart__product-title"><?php echo esc_html( $product_name ); ?></span>
								<?php else : ?>
								<a class="mini-cart__product-title" href="<?php echo esc_url( $product_permalink ); ?>"><?php echo esc_html( $product_name ); ?></a>
								<?php endif; ?>
							<?php echo apply_filters( 'woocommerce_widget_cart_item_quantity', '<span class="mini-cart__product-quantity">' . sprintf( '%s &times; %s', $cart_item['quantity'], $product_price ) . '</span>', $cart_item, $cart_item_key ); ?>
						</div>
						<?php echo wc_get_formatted_cart_item_data( $cart_item ); ?>
					</li>
					<?php
				}
			}
		?>

<?php else : ?>

		<li class="mini-cart__empty"><?php _e( 'No products in the cart.', 'healthcoach' ); ?></li>

<?php endif; ?>

</ul><!-- end product list -->

<?php if ( ! WC()->cart->is_empty() ) : ?>
		<div class="mini-cart__price-total"><?php _e( 'Subtotal', 'healthcoach' ); ?>: <?php echo WC()->cart->get_cart_subtotal(); ?></div>
		<div class="mini-cart__actions">
			<a href="<?php echo wc_get_checkout_url(); ?>" class="btn btn_size_sm btn_view_primary"><?php _e( 'Checkout', 'healthcoach' ); ?></a>
			<a href="<?php echo wc_get_cart_url(); ?>" class="mini-cart__action-link"><?php _e( 'View cart', 'healthcoach' ); ?></a>
		</div>

<?php endif; ?>

</div>